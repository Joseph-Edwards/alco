Main changes from ALCO 0.1 to ALCO 0.2 (Feb 2024)
-------------------------------------------------

1. Significant revision of the documentation.

2. Audit of the code to comport with the documentation.

3. Included a number of integer rings and removed `OctonionArithmetic`.

4. Initial set of Github issues resolved. 
